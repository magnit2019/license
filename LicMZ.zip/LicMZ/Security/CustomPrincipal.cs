﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using Sync.Models;

namespace Sync.Security
{
    public class CustomPrincipal : IPrincipal
    {
        private Account Account;
        public static bool IsRol = false;
        public CustomPrincipal(Account action)
        {
            this.Account = action;
            this.Identity = new GenericIdentity(action.Login);
            IsRol = IsInRole("superadmin,admin");
        }
        public static bool IsRols
        {
            get { return IsRol; }
        }
        public IIdentity Identity
        {
            get;
            set;
        }

        public bool IsInRole(string role)
        {
            var r = role.Split(new char[] { ',' });
            return r.Any(rr => this.Account.Roles.Contains(rr));
        }
    }
}