﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LicMZ.Security
{
    public class CustomAuthorizeAttribute: AuthorizeAttribute
    {
        public override void OnAuthorization(AuthorizationContext filterContext)
        {
            if (string.IsNullOrEmpty(SessionPersister.Login))
                filterContext.Result = new RedirectToRouteResult(new System.Web.Routing.RouteValueDictionary(
                    new { controller = "Account", action = "Login" }));
            else
            {
                Account acount = new Account();
                acount.Login = SessionPersister.Login;
                AccountModel am = new AccountModel(acount);
                CustomPrincipal cp = new CustomPrincipal(am.find(SessionPersister.Login));
                if (!cp.IsInRole(Roles))
                    filterContext.Result = new RedirectToRouteResult(new System.Web.Routing.RouteValueDictionary
                        (new { controller = "AccessDenied", action = "Index" }));
            }
        }


    }
}