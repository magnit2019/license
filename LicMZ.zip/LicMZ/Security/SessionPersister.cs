﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LicMZ.Security
{
    public static class SessionPersister
    {
        static string usernameSessinvar = "login";
        public static string Login
        {
            get
            {
                if (HttpContext.Current==null)
                    return string.Empty;
                var sessinvar = HttpContext.Current.Session[usernameSessinvar];
                if (sessinvar != null)
                    return sessinvar as string;
                return null;
            }
            set
            {
                HttpContext.Current.Session[usernameSessinvar] = value;
            }
        }

    }
}