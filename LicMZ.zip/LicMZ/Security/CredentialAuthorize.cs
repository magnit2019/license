﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;

namespace LicMZ.Security
{
    public class CredentialAuthorize: AuthorizeAttribute
    {
        private const string AuthResponseHeaders = "WWW-Authenticate";
        private const string AuthResponseHeadersValue = "Basic";

        public override void OnAuthorization(HttpActionContext actionContext)
        {
            try
            {
                var authvalue = actionContext.Request.Headers.GetValues("Authorization").FirstOrDefault();
                //AuthenticationHeaderValue authvalue = actionContext.Request.Headers.Authorization;
                if (!string.IsNullOrEmpty(authvalue))
                {
                    Credentials parsedCredentials = ParseAuthorizationHeader(authvalue.ToString());
                    if (parsedCredentials==null)
                    {
                        actionContext.Response = actionContext.Request.CreateResponse(System.Net.HttpStatusCode.Unauthorized,
                            "Ошибка авторизации.");
                        actionContext.Response.Headers.Add(AuthResponseHeaders, AuthResponseHeadersValue);
                        return;
                    }
                    string sha = HashCrytography.getHash(parsedCredentials.Login+parsedCredentials.Password);
                    Account account = new Account() { Login = parsedCredentials.Login, Password = sha };
                    List<Account> List = new List<Account>();

                    List = DataBaseManager.GetUser(account);
                    if (List.Count==0 || List==null)
                    {
                        actionContext.Response = actionContext.Request.CreateResponse(System.Net.HttpStatusCode.Unauthorized,
                            "Ошибка авторизации.");
                        actionContext.Response.Headers.Add(AuthResponseHeaders, AuthResponseHeadersValue);
                        return;
                    }
                    Account acnt = List[0] as Account;
                    AccountModel am = new AccountModel(acnt);
                    CustomPrincipal cp = new CustomPrincipal(am.find(acnt.Login));
                    if (!cp.IsInRole(Roles))
                    {
                        actionContext.Response = actionContext.Request.CreateResponse(System.Net.HttpStatusCode.Unauthorized,
                            "Ошибка авторизации.");
                        actionContext.Response.Headers.Add(AuthResponseHeaders, AuthResponseHeadersValue);
                        return;
                    }
                }
                else
                {
                    actionContext.Response = actionContext.Request.CreateResponse(System.Net.HttpStatusCode.Unauthorized);
                    actionContext.Response.Headers.Add(AuthResponseHeaders, AuthResponseHeadersValue);
                }
            }
            catch
            {
                actionContext.Response = actionContext.Request.CreateResponse(System.Net.HttpStatusCode.Unauthorized, "Ошибка авторизации.");
                actionContext.Response.Headers.Add(AuthResponseHeaders, AuthResponseHeadersValue);
            }
        }

        private Credentials ParseAuthorizationHeader(string authHeader)
        {
            string[] credential = Encoding.UTF8.GetString(Convert.FromBase64String(authHeader)).Split(new[] { ':' });
            if (credential.Length != 2 || string.IsNullOrEmpty(credential[0]) ||
                string.IsNullOrEmpty(credential[1]))
                return null;
            return new Credentials() { Login = credential[0], Password = credential[1] };

        }
    }
}