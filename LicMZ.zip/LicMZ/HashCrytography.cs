﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Security;
using System.Security.Cryptography;
using System.Text;

namespace Sync.Security
{
    public class HashCrytography
    {
        public static string getHash(string logpwd)
        {
            byte[] hash;
            using (var sha = new SHA1CryptoServiceProvider())
            {
                hash = sha.ComputeHash(Encoding.Unicode.GetBytes(logpwd));
            }

            var strbuild = new StringBuilder();
            foreach (var b in hash) strbuild.AppendFormat("{0:x2}", b);
            return strbuild.ToString();
        }
    }
}